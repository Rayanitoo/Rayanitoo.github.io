export const CHAR_SETS = {
  lowercase: 'abcdefghijklmnopqrstuvwxyz',
  uppercase: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
  numbers: '0123456789',
  symbols: '!@#$%^&*()_+-=[]{}|;:,.<>?'
} as const;

export const PASSWORD_LENGTH = {
  MIN: 4,
  MAX: 32,
  DEFAULT: 12
} as const;

export const STRENGTH_THRESHOLDS = {
  STRONG: 80,
  GOOD: 60,
  FAIR: 40,
  WEAK: 0
} as const;