import React from 'react';
import { FaClipboard } from 'react-icons/fa';

interface CopyButtonProps {
  text: string;
  onCopy: () => void;
  disabled?: boolean;
}

export const CopyButton: React.FC<CopyButtonProps> = ({ text, onCopy, disabled }) => {
  return (
    <button
      onClick={onCopy}
      disabled={disabled}
      className="p-2 text-gray-400 hover:text-white disabled:opacity-50"
      title="Copy to clipboard"
    >
      <FaClipboard />
    </button>
  );
};