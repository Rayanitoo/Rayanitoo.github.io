import React from 'react';
import { FaSync } from 'react-icons/fa';

interface GenerateButtonProps {
  onClick: () => void;
  className?: string;
}

export const GenerateButton: React.FC<GenerateButtonProps> = ({ onClick, className }) => {
  return (
    <button
      onClick={onClick}
      className={`p-2 text-gray-400 hover:text-white ${className}`}
      title="Generate new password"
    >
      <FaSync />
    </button>
  );
};