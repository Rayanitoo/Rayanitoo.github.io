import React from 'react';
import { PasswordOptions as Options } from '../../types/password';
import { PASSWORD_LENGTH } from '../../constants/password';

interface PasswordOptionsProps {
  options: Options;
  onOptionsChange: (options: Options) => void;
}

export const PasswordOptions: React.FC<PasswordOptionsProps> = ({ options, onOptionsChange }) => {
  const handleChange = (field: keyof Options, value: boolean | number) => {
    onOptionsChange({ ...options, [field]: value });
  };

  return (
    <div className="space-y-4">
      <div>
        <label className="flex items-center justify-between">
          <span>Password Length:</span>
          <input
            type="number"
            min={PASSWORD_LENGTH.MIN}
            max={PASSWORD_LENGTH.MAX}
            value={options.length}
            onChange={(e) => handleChange('length', 
              Math.max(PASSWORD_LENGTH.MIN, 
              Math.min(PASSWORD_LENGTH.MAX, 
              parseInt(e.target.value) || PASSWORD_LENGTH.MIN))
            )}
            className="w-20 px-2 py-1 bg-gray-700 rounded border border-gray-600 focus:border-purple-500 focus:ring-purple-500"
          />
        </label>
      </div>
      
      {[
        { key: 'includeLowercase', label: 'Include Lowercase Letters (a-z)' },
        { key: 'includeUppercase', label: 'Include Uppercase Letters (A-Z)' },
        { key: 'includeNumbers', label: 'Include Numbers (0-9)' },
        { key: 'includeSymbols', label: 'Include Symbols (!@#$%^&*)' }
      ].map(({ key, label }) => (
        <label key={key} className="flex items-center space-x-2">
          <input
            type="checkbox"
            checked={options[key as keyof Options] as boolean}
            onChange={(e) => handleChange(key as keyof Options, e.target.checked)}
            className="rounded bg-gray-700 border-gray-600 text-purple-600 focus:ring-purple-500"
          />
          <span>{label}</span>
        </label>
      ))}
    </div>
  );
};