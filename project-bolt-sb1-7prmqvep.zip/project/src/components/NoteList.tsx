import React from 'react';
import { Note } from '../utils/storage';
import { FaTrash } from 'react-icons/fa';

interface NoteListProps {
  notes: Note[];
  onDelete: (id: string) => void;
}

export const NoteList: React.FC<NoteListProps> = ({ notes, onDelete }) => {
  return (
    <div className="space-y-4">
      {notes.map((note) => (
        <div
          key={note.id}
          className="p-4 rounded-lg bg-gray-700 hover:bg-gray-600 transition-colors"
        >
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-lg font-semibold text-white">{note.title}</h3>
              <p className="text-gray-300 mt-2">{note.content}</p>
              <p className="text-sm text-gray-400 mt-2">
                {new Date(note.createdAt).toLocaleDateString()}
              </p>
            </div>
            <button
              onClick={() => onDelete(note.id)}
              className="text-red-400 hover:text-red-500 transition-colors"
            >
              <FaTrash />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};