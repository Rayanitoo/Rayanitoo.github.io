import React from 'react';
import { getPasswordStrengthInfo } from '../../utils/password/strength';

interface PasswordStrengthIndicatorProps {
  strength: number;
}

export const PasswordStrengthIndicator: React.FC<PasswordStrengthIndicatorProps> = ({ strength }) => {
  const strengthInfo = getPasswordStrengthInfo(strength);

  return (
    <div className="mt-4">
      <div className="flex justify-between mb-1">
        <span className="text-sm text-gray-300">Password Strength:</span>
        <span className="text-sm text-gray-300">{strengthInfo.label}</span>
      </div>
      <div className="w-full bg-gray-700 rounded-full h-2.5">
        <div
          className={`h-2.5 rounded-full transition-all duration-300 ${strengthInfo.color}`}
          style={{ width: `${strength}%` }}
        ></div>
      </div>
    </div>
  );
};