import React, { useState } from 'react';
import { Note } from '../utils/storage';

interface NoteFormProps {
  onSave: (note: Omit<Note, 'id' | 'createdAt'>) => void;
}

export const NoteForm: React.FC<NoteFormProps> = ({ onSave }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;
    
    onSave({ title, content });
    setTitle('');
    setContent('');
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <input
          type="text"
          placeholder="Note Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full px-4 py-2 rounded-lg bg-gray-700 text-white border-gray-600 focus:border-purple-500 focus:ring-purple-500"
        />
      </div>
      <div>
        <textarea
          placeholder="Write your note..."
          value={content}
          onChange={(e) => setContent(e.target.value)}
          rows={4}
          className="w-full px-4 py-2 rounded-lg bg-gray-700 text-white border-gray-600 focus:border-purple-500 focus:ring-purple-500"
        />
      </div>
      <button
        type="submit"
        className="w-full px-4 py-2 text-white bg-purple-600 rounded-lg hover:bg-purple-700 transition-colors"
      >
        Save Note
      </button>
    </form>
  );
};