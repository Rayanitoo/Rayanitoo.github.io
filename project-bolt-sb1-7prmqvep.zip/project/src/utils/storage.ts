// Local storage utilities
export const saveNotes = (notes: Note[]) => {
  localStorage.setItem('notes', JSON.stringify(notes));
};

export const loadNotes = (): Note[] => {
  const saved = localStorage.getItem('notes');
  return saved ? JSON.parse(saved) : [];
};

export interface Note {
  id: string;
  title: string;
  content: string;
  createdAt: string;
}