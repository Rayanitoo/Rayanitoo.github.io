import { STRENGTH_THRESHOLDS } from '../../constants/password';
import { PasswordStrength } from '../../types/password';

export const calculatePasswordStrength = (password: string): number => {
  if (!password) return 0;
  
  let strength = 0;
  if (password.length >= 8) strength += 25;
  if (password.length >= 12) strength += 25;
  if (/[a-z]/.test(password)) strength += 10;
  if (/[A-Z]/.test(password)) strength += 10;
  if (/[0-9]/.test(password)) strength += 10;
  if (/[^A-Za-z0-9]/.test(password)) strength += 20;

  return Math.min(strength, 100);
};

export const getPasswordStrengthInfo = (strength: number): PasswordStrength => {
  if (strength >= STRENGTH_THRESHOLDS.STRONG) {
    return { score: strength, label: 'Strong', color: 'bg-green-500' };
  }
  if (strength >= STRENGTH_THRESHOLDS.GOOD) {
    return { score: strength, label: 'Good', color: 'bg-yellow-500' };
  }
  if (strength >= STRENGTH_THRESHOLDS.FAIR) {
    return { score: strength, label: 'Fair', color: 'bg-orange-500' };
  }
  return { score: strength, label: 'Weak', color: 'bg-red-500' };
};