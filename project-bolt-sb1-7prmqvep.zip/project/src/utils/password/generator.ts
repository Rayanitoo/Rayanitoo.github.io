import { PasswordOptions } from '../../types/password';
import { CHAR_SETS } from '../../constants/password';

export const generatePassword = (options: PasswordOptions): string => {
  let chars = '';
  if (options.includeLowercase) chars += CHAR_SETS.lowercase;
  if (options.includeUppercase) chars += CHAR_SETS.uppercase;
  if (options.includeNumbers) chars += CHAR_SETS.numbers;
  if (options.includeSymbols) chars += CHAR_SETS.symbols;

  if (chars === '') return '';

  let password = '';
  const array = new Uint32Array(options.length);
  crypto.getRandomValues(array);

  for (let i = 0; i < options.length; i++) {
    password += chars[array[i] % chars.length];
  }

  return password;
};