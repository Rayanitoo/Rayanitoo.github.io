import React from 'react';
import { usePasswordGenerator } from './hooks/usePasswordGenerator';
import { calculatePasswordStrength } from './utils/password/strength';
import { PasswordOptions } from './components/options/PasswordOptions';
import { PasswordStrengthIndicator } from './components/indicators/PasswordStrengthIndicator';
import { CopyButton } from './components/buttons/CopyButton';
import { GenerateButton } from './components/buttons/GenerateButton';

function App() {
  const {
    password,
    options,
    setOptions,
    generateNewPassword,
    copyToClipboard
  } = usePasswordGenerator();

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-8 max-w-md">
        <h1 className="text-3xl font-bold text-center mb-8">Password Generator</h1>
        
        <div className="bg-gray-800 rounded-lg p-6 shadow-lg space-y-6">
          <div className="relative">
            <input
              type="text"
              readOnly
              value={password}
              placeholder="Generated password"
              className="w-full px-4 py-3 bg-gray-700 rounded-lg text-white border border-gray-600 focus:border-purple-500 focus:ring-purple-500"
            />
            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex space-x-2">
              <CopyButton
                text={password}
                onCopy={copyToClipboard}
                disabled={!password}
              />
              <GenerateButton onClick={generateNewPassword} />
            </div>
          </div>

          <PasswordStrengthIndicator strength={calculatePasswordStrength(password)} />
          
          <PasswordOptions
            options={options}
            onOptionsChange={setOptions}
          />

          <button
            onClick={generateNewPassword}
            className="w-full px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
          >
            Generate Password
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;