import { useState, useCallback } from 'react';
import { PasswordOptions } from '../types/password';
import { generatePassword } from '../utils/password/generator';
import { PASSWORD_LENGTH } from '../constants/password';

export const usePasswordGenerator = () => {
  const [password, setPassword] = useState('');
  const [options, setOptions] = useState<PasswordOptions>({
    length: PASSWORD_LENGTH.DEFAULT,
    includeLowercase: true,
    includeUppercase: true,
    includeNumbers: true,
    includeSymbols: true
  });

  const generateNewPassword = useCallback(() => {
    const newPassword = generatePassword(options);
    setPassword(newPassword);
  }, [options]);

  const copyToClipboard = useCallback(async () => {
    if (!password) return;
    await navigator.clipboard.writeText(password);
    alert('Password copied to clipboard!');
  }, [password]);

  return {
    password,
    options,
    setOptions,
    generateNewPassword,
    copyToClipboard
  };
};